#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats pexp
#' @importFrom stats pnorm
#' @importFrom stats qnorm
#' @importFrom stats t.test
## usethis namespace: end
NULL
